echo "Installing imagemagick... (This requires Homebrew)"
# This requires Homebrew: http://brew.sh/
brew install imagemagick
# imagemagick provides the `convert` utility, used to generate ICO files
