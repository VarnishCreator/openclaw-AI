import "../../src/logging/subsystem.js";

console.log("tsx-name-repro: loaded logging/subsystem");
